var transparent = true;
var transparentDemo = true;
var fixedTop = false;
var navbar_initialized = false;

$(document).ready(function(){
    window_width = $(window).width();

    burger_menu = $('nav[role="navigation-demo"]').hasClass('navbar-burger') ? true : false;

    // Init navigation toggle for small screens
    if(window_width < 768 || burger_menu){
        rex_demo.initRightMenu();
    }

    //  Activate the tooltips
    $('[rel="tooltip"]').tooltip({
         container: 'body',
         selector: 'body'
    });

    $('.btn-tooltip').tooltip();
    $('.label-tooltip').tooltip();

    //      Activate the switches with icons
    if($('.switch').length != 0){
        $('.switch')['bootstrapSwitch']();
    }
    //      Activate regular switches
    if($("[data-toggle='switch']").length != 0){
         $("[data-toggle='switch']").wrap('<div class="switch" />').parent().bootstrapSwitch();
    }

    //    Activate bootstrap-select
    if($(".selectpicker").length != 0){
        $(".selectpicker").selectpicker();
    }

    $('.form-control').on("focus", function(){
        $(this).parent('.input-group').addClass("input-group-focus");
    }).on("blur", function(){
        $(this).parent(".input-group").removeClass("input-group-focus");
    });

});

// activate collapse right menu when the windows is resized
$(window).resize(function(){
    if($(window).width() < 768){
        rex_demo.initRightMenu();
    }
    if($(window).width() >= 768 && !burger_menu){
        $('nav[role="navigation-demo"]').removeClass('navbar-burger');
        rex_demo.misc.navbar_menu_visible = 0;
        navbar_initialized = false;
        $('html').removeClass('nav-open');
    }
});

rex_demo = {
    misc:{
        navbar_menu_visible: 0
    },
    initRightMenu: function(){
        if(!navbar_initialized){
           $nav = $('nav[role="navigation-demo"]');
           $nav.addClass('navbar-burger');

           $navbar = $nav.find('.navbar-collapse').first().clone(true);

           ul_content = '';

           $navbar.children('ul').each(function(){
               content_buff = $(this).html();
               ul_content = ul_content + content_buff;
           });

           ul_content = '<ul class="nav navbar-nav">' + ul_content + '</ul>';
           $navbar.html(ul_content);

           $('body').append($navbar);

           background_image = $navbar.data('nav-image');
           if(background_image != undefined){
               $navbar.css('background',"url('" + background_image + "')")
                      .removeAttr('data-nav-image')
                      .css('background-size',"cover")
                      .addClass('has-image');
           }

           $toggle = $('.navbar-toggle');

           $navbar.find('a, button').removeClass('btn btn-round btn-default btn-simple btn-neutral btn-fill btn-info btn-primary btn-success btn-danger btn-warning');
           $navbar.find('button').addClass('btn-simple btn-block');

           $toggle.click(function (){

               if(rex_demo.misc.navbar_menu_visible == 1) {
                   $('html').removeClass('nav-open');
                   rex_demo.misc.navbar_menu_visible = 0;
                   $('#bodyClick').remove();
                    setTimeout(function(){
                       $toggle.removeClass('toggled');
                    }, 550);

               } else {
                   setTimeout(function(){
                       $toggle.addClass('toggled');
                   }, 580);

                   div = '<div id="bodyClick"></div>';
                   $(div).appendTo("body").click(function() {
                       $('html').removeClass('nav-open');
                       rex_demo.misc.navbar_menu_visible = 0;
                       $('#bodyClick').remove();
                        setTimeout(function(){
                           $toggle.removeClass('toggled');
                        }, 550);
                   });

                   $('html').addClass('nav-open');
                   rex_demo.misc.navbar_menu_visible = 1;

               }
           });
           navbar_initialized = true;
       }

    },

    fitBackgroundForCards: function(){
         $('.card').each(function(){
            if(!$(this).hasClass('card-product') && !$(this).hasClass('card-user')){
                image = $(this).find('.image img');

                image.hide();
                image_src = image.attr('src');

                $(this).find('.image').css({
                    "background-image": "url('" + image_src + "')",
                    "background-position": "center center",
                    "background-size": "cover"
                });
            }
        });
    },
    initPopovers: function(){
        if($('[data-toggle="popover"]').length != 0){
            $('body').append('<div class="popover-filter"></div>');

            //    Activate Popovers
           $('[data-toggle="popover"]').popover().on('show.bs.popover', function () {
                $('.popover-filter').click(function(){
                    $(this).removeClass('in');
                    $('[data-toggle="popover"]').popover('hide');
                });
                $('.popover-filter').addClass('in');

            }).on('hide.bs.popover', function(){
                $('.popover-filter').removeClass('in');
            });

        }
    }
}

// Returns a function, that, as long as it continues to be invoked, will not
// be triggered. The function will be called after it stops being called for
// N milliseconds. If `immediate` is passed, trigger the function on the
// leading edge, instead of the trailing.

function debounce(func, wait, immediate) {
	var timeout;
	return function() {
		var context = this, args = arguments;
		clearTimeout(timeout);
		timeout = setTimeout(function() {
			timeout = null;
			if (!immediate) func.apply(context, args);
		}, wait);
		if (immediate && !timeout) func.apply(context, args);
	};
};
